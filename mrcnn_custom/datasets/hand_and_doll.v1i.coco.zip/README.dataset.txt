# hand_and_doll > 2022-08-30 11:18am
https://universe.roboflow.com/object-detection/hand_and_doll

Provided by Roboflow
License: MIT

